#include "stdafx.h"

#include "opencv2/opencv.hpp"

#include "opencv2/objdetect.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"

#include <iostream>
#include <stdio.h>

using namespace std;
using namespace cv;

/** Function Headers */
void detectAndDisplay(Mat frame);

/** Global variables */
String face_cascade_name = "haarcascade_frontalface_alt.xml";
String eyes_cascade_name = "haarcascade_eye_tree_eyeglasses.xml";
CascadeClassifier face_cascade;
CascadeClassifier eyes_cascade;
String window_name = "Capture - Face detection";

KalmanFilter KF(4, 2, 0);
Mat_<float> measurement(2, 1);
KalmanFilter KF2(4, 2, 0);
Mat_<float> measurement2(2, 1);
vector<Point> facecenter, kalman_fs, kalman_fp;

/** @function main */
int main(void)
{
    VideoCapture capture;
    Mat frame;

    //-- 1. Load the cascades
    if (!face_cascade.load(face_cascade_name)) { printf("--(!)Error loading face cascade\n"); return -1; };
    if (!eyes_cascade.load(eyes_cascade_name)) { printf("--(!)Error loading eyes cascade\n"); return -1; };

    //-- 2. Read the video stream
    capture.open(0);
    if (!capture.isOpened()) { printf("--(!)Error opening video capture\n"); return -1; }

    // intialization of KF...
    KF.transitionMatrix = (Mat_<float>(4, 4) << 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1);   //��� A  Matrix ��Ҵ 4*4  <---�������������ͧ��Ѻ

    KF.statePre.at<float>(0) = 0;
    KF.statePre.at<float>(1) = 0;
    KF.statePre.at<float>(2) = 0;
    KF.statePre.at<float>(3) = 0;

    setIdentity(KF.measurementMatrix);
    setIdentity(KF.processNoiseCov, Scalar::all(1e-4));
    setIdentity(KF.measurementNoiseCov, Scalar::all(1e-3));   //��Ҥ����١��ͧ  ��Ѻ��   ����������Ͷ�ͧ͢�����  ���¤�����Ͷ���ҡ
    setIdentity(KF.errorCovPost, Scalar::all(1e-4));


    // intialization of KF2...
    KF2.transitionMatrix = (Mat_<float>(4, 4) << 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1);   //��� A  Matrix ��Ҵ 4*4  <---�������������ͧ��Ѻ

    KF2.statePre.at<float>(0) = 0;
    KF2.statePre.at<float>(1) = 0;
    KF2.statePre.at<float>(2) = 0;
    KF2.statePre.at<float>(3) = 0;

    setIdentity(KF2.measurementMatrix);
    setIdentity(KF2.processNoiseCov, Scalar::all(1e-4));
    setIdentity(KF2.measurementNoiseCov, Scalar::all(1e-3));   //��Ҥ����١��ͧ  ��Ѻ��   ����������Ͷ�ͧ͢�����  ���¤�����Ͷ���ҡ
    setIdentity(KF2.errorCovPost, Scalar::all(1e-4));

    measurement.setTo(Scalar(0));
    measurement2.setTo(Scalar(0));
    facecenter.clear();
    kalman_fs.clear();
    kalman_fp.clear();


    while (capture.read(frame))
    {


        if (frame.empty())
        {
            printf(" --(!) No captured frame -- Break!");
            break;
        }

        //-- 3. Apply the classifier to the frame
        detectAndDisplay(frame);


        int c = waitKey(10);
        if ((char)c == 27) { break; } // escape
    }
    return 0;
}


/** @function detectAndDisplay */
void detectAndDisplay(Mat frame)
{
    std::vector<Rect> faces;
    Mat frame_gray;

    cvtColor(frame, frame_gray, COLOR_BGR2GRAY);
    equalizeHist(frame_gray, frame_gray);

    //-- Detect faces
    face_cascade.detectMultiScale(frame_gray, faces, 1.1, 2, 0 | CASCADE_SCALE_IMAGE, Size(30, 30));

    // First predict, to update the internal statePre variable
    Mat prediction = KF.predict();
    Point predictPt(prediction.at<float>(0), prediction.at<float>(1));
    Mat estimated;

    Mat prediction2 = KF2.predict();
    Point predictPt2(prediction2.at<float>(0), prediction2.at<float>(1));
    Mat estimated2;




    for (size_t i = 0; i < faces.size(); i++)
    {
        //Point center(faces[i].x + faces[i].width / 2, faces[i].y + faces[i].height / 2);
        //ellipse(frame, center, Size(faces[i].width / 2, faces[i].height / 2), 0, 0, 360, Scalar(255, 0, 255), 4, 8, 0);

        //printf("width x : %d   hight y : %d\n", faces[i].x, faces[i].y);
        //printf("width : %d   hight : %d\n", faces[i].width, + faces[i].height);


        int x, y, w, h;
        x = faces[i].x + faces[i].width / 2;
        y = faces[i].y + faces[i].height / 2;
        w = faces[i].width;
        h = faces[i].height;

        // Get  point
        measurement(0) = x;
        measurement(1) = y;


        // The update phase  ��� correct
        estimated = KF.correct(measurement);


        // Get  point
        measurement2(0) = x;
        measurement2(1) = y;


        // The update phase
        estimated2 = KF2.correct(measurement2);


    }

    Point statePt;
    Point measPt;
    Point statePt2;
    Point measPt2;


    if (faces.size() > 0)
    {
        statePt.x = estimated.at<float>(0);
        statePt.y = estimated.at<float>(1);
        measPt.x = measurement(0);
        measPt.y = measurement(1);

        statePt2.x = estimated2.at<float>(0);
        statePt2.y = estimated2.at<float>(1);
        measPt2.x = measurement2(0);
        measPt2.y = measurement2(1);

        facecenter.push_back(measPt);

        kalman_fp.push_back(statePt);
        kalman_fs.push_back(statePt2);

    }

    else
    {
        statePt.x = prediction.at<float>(0);
        statePt.y = prediction.at<float>(1);

        statePt2.x = prediction2.at<float>(0);
        statePt2.y = prediction2.at<float>(1);

        kalman_fp.push_back(statePt);
        kalman_fs.push_back(statePt2);
    }


    Point pt1(statePt.x - statePt2.x / 2, statePt.y - statePt2.y / 2);
    Point pt2(statePt.x + statePt2.x / 2, statePt.y + statePt2.y / 2);

    rectangle(frame, pt1, pt2, Scalar(0, 255, 0), 3);


    //for (int i = 2; i < facecenter.size() - 1; i++)
        //line(frame, facecenter[i], facecenter[i + 1], Scalar(255, 0, 0), 1);

    //for (int i = 2; i < kalman_fp.size() - 1; i++)
        //line(frame, kalman_fp[i], kalman_fp[i + 1], Scalar(0, 0, 255), 1);


    imshow(window_name, frame);



}