
#include "stdafx.h"

#include "opencv2/opencv.hpp"

#include "opencv2/objdetect.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"

#include <iostream>
#include <stdio.h>

using namespace std;
using namespace cv;

//Function Headers
void detectAndDisplay(Mat frame);

// Global variables
String face_mask_name = "C:\\Users\\ACER\\Desktop\\4.1\\COMPVITION\\LAB08\\LAB08\\cascade.xml";

CascadeClassifier face_mask;

String window_name = "Capture - Face detection";


// @function main
int main8d(void)
{
    VideoCapture capture;
    Mat frame;

    //-- 1. Load the cascades
    if (!face_mask.load(face_mask_name)) { printf("--(!)Error loading face cascade\n"); return -1; };


    //-- 2. Read the video stream
    capture.open(0);
    if (!capture.isOpened()) { printf("--(!)Error opening video capture\n"); return -1; }


    while (capture.read(frame))
    {
        //printf("nikom");

        if (frame.empty())
        {
            printf(" --(!) No captured frame -- Break!");
            break;
        }

        //-- 3. Apply the classifier to the frame
        detectAndDisplay(frame);

        int c = waitKey(20);
        if ((char)c == 27) { break; } // escape
    }
    return 0;
}

// @function detectAndDisplay
void detectAndDisplay(Mat frame)
{
    std::vector<Rect> faces;
    Mat frame_gray;
    Mat crop, scrr;
    //frame.copyTo(scrr);
    cvtColor(frame, frame_gray, COLOR_BGR2GRAY);
    //equalizeHist(frame_gray, frame_gray);

    //-- Detect faces
    face_mask.detectMultiScale(frame_gray, faces, 1.1, 2, 0 | CASCADE_SCALE_IMAGE, Size(30, 30));

    for (size_t i = 0; i < faces.size(); i++)
    {
        

        Point pt1(faces[i].x, faces[i].y);
        // and its bottom right corner.
        Point pt2(faces[i].x + faces[i].width, faces[i].y + faces[i].height);

        putText(frame, "Face with mask", Point(faces[i].x, faces[i].y - 10),
            FONT_HERSHEY_COMPLEX_SMALL, 0.8, Scalar(200, 200, 250), 1);
        rectangle(frame, pt1, pt2, Scalar(0, 255, 0), 3);

    }
    //-- Show what you got
    imshow(window_name, frame);



}

