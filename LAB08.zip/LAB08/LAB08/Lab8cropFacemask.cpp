
// !!!!  The face should be in the frame in which it is placed. !!!!!!!!!!

#include "stdafx.h"
#include "opencv2/opencv.hpp"

using namespace cv;

int main82(int argc, char** argv)
{
	VideoCapture cap(0); // open the default camera
	if (!cap.isOpened())  // check if we succeeded
		return -1;

	int x = 220;
	int y = 190;
	int width = 220;
	int height = 220;

	int counter = 0;

	namedWindow("frame", 1);
	for (;;)
	{
		Mat src, dst, crop;
		cap >> src; // get a new frame from camera
		cap >> dst;

		Point pt1(x, y);
		// and its bottom right corner.
		Point pt2(x + width, y + height);
		// These two calls...
		rectangle(src, pt1, pt2, Scalar(0, 255, 0), 3);

		crop = dst(Range(pt1.y, pt1.y + height), Range(pt1.x, pt1.x + width));


		/// Display results
		imshow("frame", src);
		imshow("crop img", crop);

		String name = format("img%d.jpg", counter++);
		imwrite(name, crop);

		if (waitKey(30) >= 0) break;
	}
	// the camera will be deinitialized automatically in VideoCapture destructor
	return 0;
}
